<?php 

$email_adm = 'hvfadvocacia@gmail.com';
$url_site = 'http://localhost/delivery/';


//DADOS PARA CONEXÃO COM BD LOCAL
$banco = 'delivery';
$host = 'localhost';
$usuario = 'root';
$senha = '';

 ?>